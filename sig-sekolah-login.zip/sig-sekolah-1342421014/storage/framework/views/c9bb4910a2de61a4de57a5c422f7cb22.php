<?php $__env->startSection('title', 'Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-bold">Pengguna</h1>
    <a href="<?php echo e(route('admin.users.create')); ?>"
       class="px-4 py-2 bg-blue-700 text-white rounded">+ Tambah Pengguna</a>
</div>

<form method="GET" class="mb-4 flex gap-2">
    <select name="role" class="border rounded px-3 py-2">
        <option value="">Semua role</option>
        <?php $__currentLoopData = ['admin' => 'Admin', 'dinas' => 'Dinas Pendidikan',
                   'sekolah' => 'Sekolah']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($nilai); ?>" <?php if(request('role') === $nilai): echo 'selected'; endif; ?>>
                <?php echo e($label); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="px-4 py-2 bg-gray-700 text-white rounded">Filter</button>
</form>

<div class="bg-white rounded shadow overflow-x-auto">
<table class="w-full text-sm">
    <thead class="bg-gray-200 text-left">
        <tr>
            <th class="p-3">Nama</th>
            <th class="p-3">Email</th>
            <th class="p-3">Role</th>
            <th class="p-3">Sekolah</th>
            <th class="p-3">Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">
            <td class="p-3"><?php echo e($u->name); ?></td>
            <td class="p-3"><?php echo e($u->email); ?></td>
            <td class="p-3"><?php echo e($u->roleLabel()); ?></td>
            <td class="p-3"><?php echo e($u->sekolah?->nama ?? '-'); ?></td>
            <td class="p-3 flex gap-3">
                <a href="<?php echo e(route('admin.users.edit', $u)); ?>"
                   class="text-blue-700">Ubah</a>
                <?php if(! $u->is(auth()->user())): ?>
                    <form method="POST"
                          action="<?php echo e(route('admin.users.destroy', $u)); ?>"
                          onsubmit="return confirm('Hapus pengguna ini?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="text-red-600">Hapus</button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="5" class="p-4 text-center">Belum ada pengguna.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<div class="mt-4"><?php echo e($users->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/admin/users/index.blade.php ENDPATH**/ ?>