<?php $__env->startSection('title', 'Data Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-bold">Data Sekolah</h1>
    <a href="<?php echo e(route('dinas.sekolah.create')); ?>"
       class="px-4 py-2 bg-blue-700 text-white rounded">
        + Tambah Sekolah
    </a>
</div>

<form method="GET" class="mb-4 flex gap-2">
    <input type="text" name="q" value="<?php echo e(request('q')); ?>"
           placeholder="Cari nama, NPSN, atau kecamatan"
           class="border rounded px-3 py-2 w-80">
    <button class="px-4 py-2 bg-gray-700 text-white rounded">Cari</button>
</form>

<div class="bg-white rounded shadow overflow-x-auto">
<table class="w-full text-sm">
    <thead class="bg-gray-200 text-left">
        <tr>
            <th class="p-3">No</th>
            <th class="p-3">NPSN</th>
            <th class="p-3">Nama</th>
            <th class="p-3">Jenjang</th>
            <th class="p-3">Status</th>
            <th class="p-3">Kecamatan</th>
            <th class="p-3">Koordinat</th>
            <th class="p-3">Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="border-t">
            <td class="p-3"><?php echo e($sekolahs->firstItem() + $loop->index); ?></td>
            <td class="p-3"><?php echo e($s->npsn); ?></td>
            <td class="p-3"><?php echo e($s->nama); ?></td>
            <td class="p-3"><?php echo e($s->jenjang); ?></td>
            <td class="p-3"><?php echo e($s->status); ?></td>
            <td class="p-3"><?php echo e($s->kecamatan); ?></td>
            <td class="p-3 font-mono text-xs">
                <?php echo e($s->latitude); ?>, <?php echo e($s->longitude); ?>

            </td>
            <td class="p-3 flex gap-3">
                <a href="<?php echo e(route('sekolah.edit', $s)); ?>"
                   class="text-blue-700">Ubah</a>
                <form method="POST"
                      action="<?php echo e(route('dinas.sekolah.destroy', $s)); ?>"
                      onsubmit="return confirm('Hapus data ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="text-red-600">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="p-4 text-center">Belum ada data.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<div class="mt-4"><?php echo e($sekolahs->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/admin/sekolah/index.blade.php ENDPATH**/ ?>