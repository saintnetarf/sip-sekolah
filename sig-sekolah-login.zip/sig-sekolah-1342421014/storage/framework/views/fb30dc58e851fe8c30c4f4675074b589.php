<?php $__env->startSection('title', 'Ubah Sekolah'); ?>
<?php echo $__env->make('sekolah._tab', ['sekolah' => $sekolah], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Ubah Sekolah</h1>

<form method="POST" action="<?php echo e(route('sekolah.update', $sekolah)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('admin.sekolah._form', ['sekolah' => $sekolah], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/admin/sekolah/edit.blade.php ENDPATH**/ ?>