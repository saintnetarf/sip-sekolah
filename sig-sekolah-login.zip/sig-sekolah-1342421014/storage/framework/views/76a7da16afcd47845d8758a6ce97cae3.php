<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?> - SIG Sekolah</title>
    <link rel="stylesheet"
          href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-100 text-gray-800">
    <nav class="bg-blue-800 text-white">
        <div class="max-w-6xl mx-auto px-4 py-3 flex items-center gap-6">
            <span class="font-bold">SIG Sekolah</span>
            <a href="<?php echo e(url('/')); ?>">Peta Publik</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('admin.users.index')); ?>">Pengguna</a>
                <?php endif; ?>


                <?php if(auth()->user()->isDinas()): ?>
                    <a href="<?php echo e(route('dinas.sekolah.index')); ?>">Data Sekolah</a>
                <?php endif; ?>

                <?php if(auth()->user()->isSekolah() && auth()->user()->sekolah_id): ?>
                    <a href="<?php echo e(route('sekolah.edit', auth()->user()->sekolah_id)); ?>">
                        Sekolah Saya
                    </a>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('logout')); ?>"
                      class="ml-auto flex items-center gap-3">
                    <?php echo csrf_field(); ?>
                    <span class="text-sm">
                        <?php echo e(auth()->user()->name); ?>

                        (<?php echo e(auth()->user()->roleLabel()); ?>)
                    </span>
                    <button class="underline">Keluar</button>
                </form>
            <?php endif; ?>
        </div>
    </nav>

    <main class="max-w-6xl mx-auto px-4 py-6">
        <?php if(session('success')): ?>
            <div class="mb-4 p-3 rounded bg-green-100 text-green-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="mb-4 p-3 rounded bg-red-100 text-red-800">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/layouts/app.blade.php ENDPATH**/ ?>