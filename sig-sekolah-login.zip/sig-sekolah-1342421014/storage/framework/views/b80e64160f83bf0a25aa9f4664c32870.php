<?php $__env->startSection('title', 'Profil Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-1"><?php echo e($sekolah->nama); ?></h1>
<p class="text-gray-600 mb-4">NPSN <?php echo e($sekolah->npsn); ?></p>

<?php echo $__env->make('sekolah._tab', ['sekolah' => $sekolah], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php
    $teks = [
        'kepala_sekolah' => ['Kepala Sekolah', 'text'],
        'email'          => ['Email Sekolah', 'email'],
        'website'        => ['Website (diawali https://)', 'url'],
        'tahun_berdiri'  => ['Tahun Berdiri', 'number'],
        'jumlah_siswa'   => ['Jumlah Siswa', 'number'],
        'jumlah_guru'    => ['Jumlah Guru', 'number'],
    ];
    $cls = 'w-full border rounded px-3 py-2';
?>

<form method="POST" action="<?php echo e(route('sekolah.profil.update', $sekolah)); ?>"
      class="bg-white rounded shadow p-6 grid md:grid-cols-2 gap-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php $__currentLoopData = $teks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => [$label, $type]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <label for="<?php echo e($name); ?>" class="block font-medium">
                <?php echo e($label); ?>

            </label>
            <input type="<?php echo e($type); ?>" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
                   value="<?php echo e(old($name, $profil->$name)); ?>"
                   class="<?php echo e($cls); ?>">
            <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div>
        <label for="akreditasi" class="block font-medium">Akreditasi</label>
        <select id="akreditasi" name="akreditasi" class="<?php echo e($cls); ?>">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = ['A', 'B', 'C', 'Belum Terakreditasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($o); ?>"
                    <?php if(old('akreditasi', $profil->akreditasi) === $o): echo 'selected'; endif; ?>>
                    <?php echo e($o); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['akreditasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="md:col-span-2">
        <label for="deskripsi" class="block font-medium">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" rows="5"
                  class="<?php echo e($cls); ?>"><?php echo e(old('deskripsi', $profil->deskripsi)); ?></textarea>
        <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="md:col-span-2">
        <button class="px-5 py-2 bg-blue-700 text-white rounded">
            Simpan Profil
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/sekolah/profil.blade.php ENDPATH**/ ?>