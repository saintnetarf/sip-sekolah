<?php
    $aktif = 'border-blue-700 text-blue-700';
    $biasa = 'border-transparent text-gray-600';
?>
<div class="mb-4 border-b flex gap-6">
    <a href="<?php echo e(route('sekolah.edit', $sekolah)); ?>"
       class="pb-2 border-b-2 <?php echo e(request()->routeIs('sekolah.edit') ? $aktif : $biasa); ?>">
        Data Sekolah
    </a>
    <a href="<?php echo e(route('sekolah.profil.edit', $sekolah)); ?>"
       class="pb-2 border-b-2 <?php echo e(request()->routeIs('sekolah.profil.edit') ? $aktif : $biasa); ?>">
        Profil Sekolah
    </a>
</div>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/sekolah/_tab.blade.php ENDPATH**/ ?>