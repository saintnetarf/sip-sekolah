<?php
    $teks = [
        'npsn'      => 'NPSN (8 digit)',
        'nama'      => 'Nama Sekolah',
        'kecamatan' => 'Kecamatan',
        'telepon'   => 'Telepon',
    ];
    $pilihan = [
        'jenjang' => ['SD', 'SMP', 'SMA', 'SMK'],
        'status'  => ['Negeri', 'Swasta'],
    ];
    $cls = 'w-full border rounded px-3 py-2';
?>

<div class="bg-white rounded shadow p-6 grid md:grid-cols-2 gap-6">
    <div class="space-y-4">
        <?php $__currentLoopData = $teks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label for="<?php echo e($name); ?>" class="block font-medium">
                    <?php echo e($label); ?>

                </label>
                <input type="text" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
       value="<?php echo e(old($name, $sekolah->$name)); ?>"
       <?php if($name === 'npsn' && auth()->user()->isSekolah()): echo 'readonly'; endif; ?>
       class="<?php echo e($cls); ?>">

                <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $pilihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label for="<?php echo e($name); ?>" class="block font-medium">
                    <?php echo e(ucfirst($name)); ?>

                </label>
                <select id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
                        class="<?php echo e($cls); ?>">
                    <option value="">-- Pilih --</option>
                    <?php $__currentLoopData = $opsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o); ?>"
                            <?php if(old($name, $sekolah->$name) === $o): echo 'selected'; endif; ?>>
                            <?php echo e($o); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div>
            <label for="alamat" class="block font-medium">Alamat</label>
            <textarea id="alamat" name="alamat" rows="3"
                      class="<?php echo e($cls); ?>"><?php echo e(old('alamat', $sekolah->alamat)); ?></textarea>
            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="space-y-4">
        <p class="font-medium">
            Klik peta atau geser marker untuk menentukan lokasi sekolah
        </p>
        <div id="map-picker" class="h-80 rounded border"></div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label for="latitude" class="block font-medium">Latitude</label>
                <input type="number" step="any" id="latitude" name="latitude"
                       value="<?php echo e(old('latitude', $sekolah->latitude)); ?>"
                       class="<?php echo e($cls); ?>">
                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="longitude" class="block font-medium">Longitude</label>
                <input type="number" step="any" id="longitude" name="longitude"
                       value="<?php echo e(old('longitude', $sekolah->longitude)); ?>"
                       class="<?php echo e($cls); ?>">
                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="flex gap-3 pt-2">
            <button type="submit"
                    class="px-5 py-2 bg-blue-700 text-white rounded">
                Simpan
            </button>
            <a href="<?php echo e(auth()->user()->isDinas()
            ? route('dinas.sekolah.index')
            : route('dashboard')); ?>"
            class="px-5 py-2 bg-gray-300 rounded">Batal</a>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    const latInput = document.getElementById('latitude');
    const lngInput = document.getElementById('longitude');

    const sudahAda = latInput.value !== '' && lngInput.value !== '';
    const pusat = sudahAda
        ? [parseFloat(latInput.value), parseFloat(lngInput.value)]
        : [-3.3194, 114.5908];   // pusat Kota Banjarmasin

    const map = L.map('map-picker').setView(pusat, sudahAda ? 16 : 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const marker = L.marker(pusat, { draggable: true }).addTo(map);

    function isiKoordinat(lat, lng) {
        latInput.value = lat.toFixed(7);
        lngInput.value = lng.toFixed(7);
    }

    map.on('click', (e) => {
        marker.setLatLng(e.latlng);
        isiKoordinat(e.latlng.lat, e.latlng.lng);
    });

    marker.on('dragend', () => {
        const p = marker.getLatLng();
        isiKoordinat(p.lat, p.lng);
    });

    [latInput, lngInput].forEach((el) => {
        el.addEventListener('change', () => {
            const lat = parseFloat(latInput.value);
            const lng = parseFloat(lngInput.value);
            if (!isNaN(lat) && !isNaN(lng)) {
                marker.setLatLng([lat, lng]);
                map.setView([lat, lng], 16);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/admin/sekolah/_form.blade.php ENDPATH**/ ?>