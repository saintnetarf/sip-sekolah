<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold">Selamat datang, <?php echo e($user->name); ?></h1>
<p class="text-gray-600 mb-6">Masuk sebagai <?php echo e($user->roleLabel()); ?></p>

<?php if($user->isAdmin()): ?>
    <div class="grid md:grid-cols-3 gap-4">
        <?php $__currentLoopData = $jumlahPerRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded shadow p-5">
                <p class="text-3xl font-bold text-blue-800"><?php echo e($jumlah); ?></p>
                <p class="text-gray-600">Akun <?php echo e($label); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php elseif($user->isDinas()): ?>
    <div class="bg-white rounded shadow p-5 w-64">
        <p class="text-3xl font-bold text-blue-800"><?php echo e($jumlahSekolah); ?></p>
        <p class="text-gray-600">Sekolah terdata</p>
    </div>
<?php elseif($sekolah): ?>
    <div class="bg-white rounded shadow p-5 max-w-lg">
        <p class="text-xl font-bold"><?php echo e($sekolah->nama); ?></p>
        <p class="text-gray-600">NPSN <?php echo e($sekolah->npsn); ?>

            - <?php echo e($sekolah->jenjang); ?> <?php echo e($sekolah->status); ?></p>
        <p class="mt-4">Kelengkapan profil:
            <strong><?php echo e($kelengkapan); ?>%</strong></p>
        <div class="w-full bg-gray-200 rounded h-3 mt-1">
            <div class="bg-blue-700 h-3 rounded"
                 style="width: <?php echo e($kelengkapan); ?>%"></div>
        </div>
    </div>
<?php else: ?>
    <div class="p-4 rounded bg-yellow-100 text-yellow-800">
        Akun Anda belum ditautkan ke sekolah. Hubungi admin.
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/sig 2026/sig-sekolah-1342421014/resources/views/dashboard.blade.php ENDPATH**/ ?>